
demog.menu<-function(){
  
  print.demog.menu()
  
  letter<<-readline(">>>>")
  
  switch.demog.menu()
  
}

