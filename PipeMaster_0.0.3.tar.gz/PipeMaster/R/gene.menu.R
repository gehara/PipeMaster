gene.menu<-function(){

print.gene.menu()

letter<<-readline(">>>>")

switch.gene.menu()

}

