
time.menu<-function(){
  
  print.time.menu()
  
  letter<<-readline(">>>>")
  
  switch.time.menu()
  
}

