
join.menu<-function(){
  
  print.join.menu()
  
  letter<<-readline(">>>>")
  
  switch.join.menu()
  
}

