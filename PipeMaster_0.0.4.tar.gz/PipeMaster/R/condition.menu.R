
condition.menu<-function(){
  
  print.condition.menu()
  
  letter<<-readline(">>>>")
  
  switch.condition.menu()
  
}

