
mig.menu<-function(){
  
  print.mig.menu()
  
  letter<<-readline(">>>>")
  
  switch.mig.menu()
  
}

